#include <REGX52.H>

sfr AUXR = 0x8E;
 
void UartInit(void)	
{
	AUXR = 0x01;
	SCON = 0x40; 
	TMOD &= 0xF0;
	TMOD |= 0x20;
	TH1 = 0xFD;
	TL1 = 0xFD;
	TR1 = 1;
	ET1=0;
	EA=1;
	ES=1;
}

void Delay1000ms()
{
	unsigned char i, j, k;

	i = 8;
	j = 1;
	k = 243;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}


void sendByte(char data_msg)
	{
			SBUF = data_msg;
			while(!TI);
			TI = 0;
	}
 
void sendString(char* str)
{
	while( *str != '\0')
		{
			sendByte(*str);
			str++;
		}
}
 
void main()
{
 

	UartInit();
	
	while(1){
		Delay1000ms();

		sendString("Send successfully!\r\n");
	}
}