#include <REGX52.H>
 
typedef unsigned u16;
 
void delay(unsigned int t)
{
	while(t--);
}
 
void ConfigUART(u16 baud)
	{
		SCON=0x50; 
	  PCON=0X00;
		TMOD&=0x0F;
		TMOD|=0x20;
		TH1=256 -(11059200/12/32)/baud; 
		TL1=TH1; 
		ET1=0;
		ES=1;
		TR1=1;
		EA=1;
	}


	
void main()
{
	char data_msg = 'a';
  ConfigUART(9600);
	
	while(1)
	{
		delay(10000);
		SBUF = data_msg;
	}
}