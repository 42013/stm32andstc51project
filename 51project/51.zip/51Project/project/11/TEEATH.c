#include <reg52.h>

#include <intrins.h>

//FOSC = 11.0592MHz,12T模式,SMOD=0

#define reload_count_1200bps 0xe8

#define reload_count_2400bps 0xf4

#define reload_count_4800bps 0xfa

#define reload_count_9600bps 0xfd

#define LCD_Data P0

#define Busy 0x80  

#define uchar unsigned char

#define uint unsigned int

sbit BEEP=P2^3;

sbit LCD_RS=P1^0;

sbit LCD_RW=P1^1;

sbit LCD_E=P2^5;

uchar buf;

uchar rev_flag=0x00;

uchar code table0[]={"     SL-51A     "};

uchar code table1[]={"SERILA BAUD:9600"};

uchar code table2[]={" REV: 0123456   "};

uchar code table5[]={" SEND:SSLV-JY   "};

uchar code table6[]={" "};

void serial_port_initial(char TH,char TL);

void send_UART(unsigned char i);   

char UARTReceive(void);

void delay(int In,int Out); 

void Delay5Ms(void);

void WriteDataLCD(unsigned char WDLCD);

void WriteCommandLCD(unsigned char WCLCD,BuysC);

unsigned char ReadStatusLCD(void);

void LCDInit(void); 

void DisplayOneChar(unsigned char X,unsigned char Y,unsigned char DData);

void DisplayListChar(unsigned char X,unsigned char Y,unsigned char code *DData);

void init(void);

void display(void);

void init(void)

{

serial_port_initial(reload_count_9600bps,reload_count_9600bps);

 LCDInit();

 DisplayListChar(0,0,table0);

 DisplayListChar(0,1,table1);

}

void serial_port_initial(char TH,char TL)

{

 SCON=0x50;TMOD=0x20;PCON=0x00;

 TH1=TH;TL1=TL;

 ES=1;EA=1;TR1=1;                                                   

}

void send_UART(unsigned char i)

{

 SBUF=i;

 while(TI==0);

 TI=0;

}

void Delay5Ms(void)

{

 unsigned int TempCyc=3552;

 while(TempCyc--);

}

void WriteDataLCD(unsigned char WDLCD)

{

 ReadStatusLCD();

 LCD_Data=WDLCD;

 LCD_RS=1;

 LCD_RW=0;

 LCD_E=0;    

 LCD_E=0;

 LCD_E=1;

}

void WriteCommandLCD(unsigned char WCLCD,BuysC) 

{

 if (BuysC)ReadStatusLCD();

 LCD_Data=WCLCD;

 LCD_RS=0;

 LCD_RW=0;

 LCD_E=0;

 LCD_E=0;

 LCD_E=1;

}

unsigned char ReadStatusLCD(void)

{

 LCD_Data=0xFF;

 LCD_RS=0;

 LCD_RW=1;

 LCD_E=0;

 LCD_E=0;

 LCD_E=1;

 while(LCD_Data&Busy);

 return(LCD_Data);

}

void LCDInit(void)

{

 LCD_Data=0;

 WriteCommandLCD(0x38,0);Delay5Ms();

 WriteCommandLCD(0x38,0);Delay5Ms();

 WriteCommandLCD(0x38,0);Delay5Ms();

 WriteCommandLCD(0x38,1);      

 WriteCommandLCD(0x08,1);

 WriteCommandLCD(0x01,1);

 WriteCommandLCD(0x06,1);

 WriteCommandLCD(0x0C,1);

}

void DisplayOneChar(unsigned char X,unsigned char Y,unsigned char DData)

{

 Y&=0x1;X&=0xF;   

 if(Y)X|=0x40;

 X|=0x80;

 WriteCommandLCD(X,0); 

 WriteDataLCD(DData);

}

void DisplayListChar(unsigned char X,unsigned char Y,unsigned char code *DData)

{

 unsigned char ListLength;ListLength=0;

 Y&=0x1;X&=0xF;

 while(DData[ListLength]>=0x20)

 {

  if(X<=0xF)

  {

   DisplayOneChar(X,Y,DData[ListLength]);

   ListLength++;

   X++;

  }

 }

}

void display(void)

{

 if(rev_flag==0x36)

 {

  DisplayOneChar(0,1,table6[0]);

  DisplayOneChar(1,1,table2[1]);

  DisplayOneChar(2,1,table2[2]);

  DisplayOneChar(3,1,table2[3]);

  DisplayOneChar(4,1,table2[4]);

  DisplayOneChar(5,1,0x30);

  DisplayOneChar(6,1,0x31);

  DisplayOneChar(7,1,0x32);

  DisplayOneChar(8,1,0x33);

  DisplayOneChar(9,1,0x34);

  DisplayOneChar(10,1,0x35);

  DisplayOneChar(11,1,0x36);

  DisplayOneChar(12,1,table6[0]);

  DisplayOneChar(13,1,table6[0]);

  DisplayOneChar(14,1,table6[0]);

  DisplayOneChar(15,1,table6[0]);   

 }           

}

void main(void)

{

 init();         

 while(1){display();}

}

void serial() interrupt 4

{

 ES=0;

 RI=0;

 buf=SBUF;    

 switch(buf)

 {

  case 0x30:                  //接受到0，发送字符'S'给计算机

  {BEEP=1;rev_flag=0x30;send_UART('S');}break; 

  case 0x31:                  //接受到2，发送字符'S'给计算机

  {BEEP=1;rev_flag++;send_UART('S');}break;                                   

  case 0x32:                  //接受到3，发送字符'L'给计算机

  {BEEP=1;rev_flag++;send_UART('L');}break;                                   

  case 0x33:                  //接受到4，发送字符'V'给计算机

  {BEEP=1;rev_flag++;send_UART('V');}break;                                 

  case 0x34:                  //接受到5，发送字符'-'给计算机

  {BEEP=1;rev_flag++;send_UART('-');}break;                                        

  case 0x35:                  //接受到5，发送字符'J'给计算机  

  {BEEP=1;rev_flag++;send_UART('J');}break;                                 

  case 0x36:                  //接受到5，发送字符'Y'给计算机

  {BEEP=1;rev_flag++;send_UART('Y');}break;                                            

  default:                       //接受到其它数据，报警

  {BEEP=0;}break;                             

 }

 ES=1;                          //允许串口中断   

}