#include <REGX52.H>
#include <stdio.h>
int  flag;
sbit BEEP = P2^5;
void UART_isr1(void) interrupt 4   /??ÖÐ¶Ïº¯Êý·ÅÔÚµÄÎ»ÖÃºÜÖØÒª£¬µ±Ç°´úÂëÄÚÈÝÃ»ÎÊÌâ£¬µ«ÓÐµÄÃ»·¢»Ó³ö×÷ÓÃ¡£好
{                                    //中断可停乱码好
	
	if(RI)
	{
		RI=0;
		if(flag==0)     
    {
			flag_n++;	 /n???
			for(cnt=0;d[cnt]!='\0'&&cnt<50;cnt++)
			{
			d[cnt]='\0';  /?
			}
			cnt=0;        /?
		}
	  flag=1;
		d[cnt]=SBUF;      /?????    
		cnt++;		
		BEEP=1;
			 delay(50);
			 BEEP=0;
			 delay(50);
			Nixie(1,1);
	}
if(TI) //发送中断,可以省略
	{
		TI=0;
	}
}
