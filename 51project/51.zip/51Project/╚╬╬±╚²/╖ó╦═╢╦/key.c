//#include <REGX52.H>

//sbit K1=P3^1;
//sbit K2=P3^0;

//char msg ;

//void delay(unsigned int t)
//{
//		while(t--);
//}

//void key()
//{
//		while(1)
//		{
//				
//				if(K1==0)
//						{
//								delay(200);
//								while(K1==0);
//								delay(200);
//								msg='a';
//						}
//				else if(K2==0)
//						{
//								delay(200);
//								while(K2==0);
//								delay(200);
//								msg='b';
//						}
//		 }
//}