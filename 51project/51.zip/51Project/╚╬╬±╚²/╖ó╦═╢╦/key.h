#ifndef _KEY_H_
#define _KEY_H_

void delay(unsigned int t);
void key();

sbit K1=P3^1;
sbit K2=P3^0;
#endif