#include "reg52.h"
#include "intrins.h"

sbit k1 = P3^1;
sbit k2 = P3^0;

typedef unsigned u16; 
 
void ConfigUART(u16 baud)
	{
		SCON=0x50;
		TMOD&=0x0F;
		TMOD|=0x20;
		TH1=256 -(11059200/12/32)/baud; 
		TL1=TH1;
		ET1=0;
		ES=1;
		TR1=1;
	}

void Delay(unsigned int xms)		//@11.0592MHz
{
	unsigned char i, j;
	while(xms)
	{
		i = 2;
		j = 199;
		do
		{
			while (--j);
		} while (--i);
		xms--;
	}
	
}

void sendByte(char data_msg)
{
	SBUF = data_msg;
	while(!TI);
	TI = 0;
}

void key()
{
			char a = 'a' ;
			char b = 'b' ;
			if(k1==0)
			{
				    while(k1==0);
						Delay(10);
						sendByte(a);
			}
			else if(k2==0)
			{
						while(k2==0);
						Delay(10);
						sendByte(b);
			}
}

void main()
{
			EA=1;
			ConfigUART(9600);
			while(1)
			{
				key();
			}
}