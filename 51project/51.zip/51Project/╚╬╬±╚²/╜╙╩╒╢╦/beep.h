#ifndef _BEEP_H_
#define _BEEP_H_

void delay(unsigned int t);
void beep_one();
void beep_two();
#endif