#include <REGX52.H>

sbit beep=P2^5;

void delay(unsigned int t)
{
		while(t--);
}

void beep_one()
{
			int i = 7;
			beep=0;
			while(i--)
			{
						beep=~beep;
						delay(100);
			}
}

void beep_two()
{
		  int j = 7;
			beep=0;
			while(j--)
			{
						beep=~beep;
						delay(100000);
			}
}