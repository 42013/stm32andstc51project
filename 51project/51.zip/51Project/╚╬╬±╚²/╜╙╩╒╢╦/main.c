#include <REGX52.H>
#include "beep.h"
typedef unsigned u16;

unsigned char RxdByte;
unsigned char receiveData;


void ConfigUART(u16 baud)
	{
		SCON=0x50;
		TMOD&=0x0F;
		TMOD|=0x20;
		TH1=256 -(11059200/12/32)/baud; 
		TL1=TH1;
		ET1=0;
		ES=1;
		TR1=1;
	}


void main()
{
	EA = 1;
	  ConfigUART(9600);
		while(1)
		{
					switch(RxdByte)
					{
						case 'a':beep_one();break;
						case 'b':beep_two();break;
					}
		}
}

void InterruptUART() interrupt 4
	{
			if(RI)
					{
								RI=0;
								RxdByte=SBUF;
								SBUF=RxdByte;
					}
			if(TI)
					{
						    TI=0;
					}
	}