#ifndef __TIMER_H
#define __TIMER_H

void Timer_Init(void);
void OpenTimer(void);
void CloseTimer(void);
uint32_t  GetEchoTimer(void);

#endif
