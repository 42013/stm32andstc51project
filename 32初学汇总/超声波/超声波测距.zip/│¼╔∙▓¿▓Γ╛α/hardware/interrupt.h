#ifndef __INTERRUPT_H
#define __INTERRUPT_H
void interrupt_Init(void);
uint8_t interrupt_Get(void);

#endif
