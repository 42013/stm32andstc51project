#ifndef __LIGHTFELL_H
#define __LIGHTFELL_H

void lightfell_Init(void);
uint8_t lightfell_Get(void);

#endif
