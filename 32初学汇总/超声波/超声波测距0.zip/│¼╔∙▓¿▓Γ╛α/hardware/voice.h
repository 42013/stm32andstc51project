#ifndef __VOICE_H
#define __VOICE_H

void voice_Init(void);
uint32_t  GetEchoTimer(void);
int fileter(int lenth);
float getlength(void);

#endif
